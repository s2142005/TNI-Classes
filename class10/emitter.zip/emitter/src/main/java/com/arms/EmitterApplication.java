package com.arms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmitterApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmitterApplication.class, args);
	}
}
